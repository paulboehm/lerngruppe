#ifndef _FUNKTION_H_
#define _FUNCTION_H_

typedef struct
{
	int key;
	struct knoten *next;
} knoten;

knoten *qinit();
void enqueue (knoten *schlange, int element);
int dequeue(knoten *schlange);
int isempty(knoten *schlange);
void printQueue(knoten *schlange);
int countlist(knoten *schlange);

#endif
