#include<stdio.h>
#include <stdlib.h>
#include "function.h"


knoten *qinit()
{
	knoten *head;
	head = malloc(sizeof(knoten));
	head->key = 0;
	head->next = NULL;
	return head;
}

void enqueue (knoten *schlange, int element) //Neues Element anf�gen
{
	if(schlange == NULL)
	{
		return;
	}
	
	while(schlange->next != NULL)
	{
		schlange= (knoten*)schlange->next;
	}

	schlange->next = (struct knoten*) malloc(sizeof(knoten));
	schlange = (knoten*) schlange->next;
	
	schlange->next = NULL;
	schlange->key = element;	
}

int dequeue(knoten *schlange) //Entfernen des ersten Elementes aus der Warteschlange
{
	if(isempty(schlange)==1) 
	{
		return;
	}
	int i;
	knoten *loschlange = (knoten*)schlange->next;
	i=loschlange->key;

	schlange->next = loschlange->next;
	free(loschlange);
	return i;
}

int isempty(knoten *schlange) //R�ckgabe von 1, falls die Schlange leer ist, sonst 0
{
	if(schlange->key==0 && schlange->next==NULL) 
	{
		return 1;
	}
	else
	{
		return 0;
	}
}

void printQueue(knoten *schlange) //Ausgabe der in der Schlange gespeicherten Elemente
{
	int i;
	if(isempty(schlange)==1)
	{
		printf("Die Warteschlange ist leer.\n");
		return;
	}
	schlange= (knoten*)schlange->next;
	for(i=1; schlange != NULL; i++)
	{
		printf("%d. Element Wert:%d\n", i, schlange->key);
		schlange= (knoten*)schlange->next;
	}
}

int countlist(knoten *schlange)
{
	int i;
	for(i=-1; schlange != NULL; i++)
	{
		schlange= (knoten*)schlange->next;
	}
	return i;
}

