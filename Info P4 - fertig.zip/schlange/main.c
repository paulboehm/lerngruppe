#include<stdio.h>
#include <stdlib.h>
#include "function.h"


int main()
{
	int j;
	knoten *head;
	
	printf("Willkommen in der Warteschlangenverwaltung.\n");
	
	head = qinit();
	
	while(1)
	{
		printf("\nMenue zur Wartenschlangenverwaltung:\n");
		printf("\n1. Anfuegen eines Elementes\n"
				"2. Loeschen und Ausgeben des ersten Elementes\n"
				"3. Ausgeben der Warteschlange\n"
				"4. Anzahl der Warteschlangenelemente ausgeben.\n"
				"5. Beenden des Programms\n");
		printf("\nBitte geben sie die Ziffer der gewuenschten Funktion ein:");
		scanf("%d", &j);
		printf("\n");
		
		switch(j)
		{
			case 1://Anfuegen eines Elementes
				{
					int e;
					printf("Welchen Wert wollen sie anfuegen?");
					scanf("%d", &e);
					enqueue(head, e);
					break;
				}
			case 2://Loeschen und Ausgeben des ersten Elementes
				{
					int i;
					if(isempty(head)==1)
					{
						printf("Liste ist leer und es kann kein wert geloescht werden.\n");
					}
					else
					{
						i = dequeue(head);
						printf("Sie haben den Wert %d geloescht.\n", i);
					}
					break;                                          
				}
			case 3://Ausgeben der Warteschlange
				{
					
					printQueue(head);
					break;
				}
				
			case 4://Zaehlen
				{
					int i;
					i=countlist(head);
					printf("Die Liste enthaelt %d Werte.\n", i);
					break;
				}

			case 5://Beenden des Programms
				{
					printf("Auf Wiedersehen.");
					free(head);
					return 0;
				}
			
			default:
				{
					printf("Unglueltiger Wert!\n");
				}                       
		}	
	} 
	free(head);
	return 0;
}
