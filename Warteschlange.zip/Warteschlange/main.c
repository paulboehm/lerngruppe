#include<stdio.h>

typedef struct
{
	int key;
	struct knoten *next;
} knoten;


void enqueue (knoten *schlange, int element) //Neues Element anf�gen
{
	knoten *nextschlange;
	if(schlange == NULL) return;
	while(schlange->next != NULL)
	{
		schlange= (knoten*)schlange->next;
	}
	
	schlange->next = (struct knoten*) malloc(sizeof(knoten));
	nextschlange = (knoten*) schlange->next;
	
	nextschlange->next = NULL;
	nextschlange->key = element;	
}

int dequeue(knoten *schlange) //Entfernen des ersten Elementes aus der Warteschlange
{
	int i;
	if(schlange->next != NULL)
	{
		i = schlange->key;
		schlange->key=NULL;
		schlange->next=NULL;
		return i;
	}
	knoten *loschlange = schlange;
	loschlange= (knoten*)loschlange->next;
	i = schlange->key;
	schlange->key = loschlange->key;
	schlange->next = loschlange->next;
	return i;
}

int isempty(knoten *schlange) //R�ckgabe von 1, falls die Schlange leer ist, sonst 0
{
	if(schlange==NULL) return 1;
	else return 0;
}

void printQueue(knoten *schlange) //Ausgabe der in der Schlange gespeicherten Elemente
{
	knoten *aktschlange = schlange;
	int i;
	for(i=1; aktschlange != NULL; i++)
	{
		printf("%d. Element Wert:%d\n", i, aktschlange->key);
		aktschlange= (knoten*)aktschlange->next;
	}
}


int main()
{
	int j, ie;
	knoten *qinit = NULL;
	
	printf("Willkommen in der Warteschlangenverwaltung.\n");
	while(1)
	{
		printf("Menue zur Wartenschlangenverwaltung:\n");
		printf("1. Anfuegen eines Elementes\n2. Loeschen und Ausgeben des ersten Elementes\n3. Ausgeben der Warteschlange\n4. Beenden des Programms\n");
		printf("Bitte geben sie die Ziffer der gewuenschten Funktion ein:");
		scanf("%d", &j);
		
		switch(j)
		{
			case 1://Anfuegen eines Elementes
				{
					int e;
					printf("Welchen Wert wollen sie anfuegen?");
					scanf("%d", &e);
					ie=isempty(qinit);
					if(ie==1)
					{
						qinit = (knoten*) malloc(sizeof(knoten));
						qinit->key=e;
						qinit->next=NULL;
						break;
					}
					enqueue(qinit, e);
					break;
				}
			
			case 2://Loeschen und Ausgeben des ersten Elementes
				{
					ie=isempty(qinit);
					if(ie==1)
					{
						printf("Liste ist leer und es kann kein wert geloescht werden.");
						break;
					}
					int i;
					i = dequeue(qinit);
					printf("Sie haben den Wert %d geloescht.\n", i);
					
					ie=isempty(qinit);
					if(ie==1)
					{
						printf("Das war der einzige Wert in der Liste, diese ist nun Leer.");
						break;
					}
					break;
				}
			
			case 3://Ausgeben der Warteschlange
				{
					printQueue(qinit);
					break;
				}
			
			case 4://Beenden des Programms
				{
					return 0;
				}
		}
		printf("\n\n\n\n\n");
	}
}
